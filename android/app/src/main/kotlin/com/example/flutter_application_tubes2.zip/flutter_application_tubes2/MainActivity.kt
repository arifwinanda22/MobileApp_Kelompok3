package com.example.flutter_application_tubes2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
